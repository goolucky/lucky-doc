#!/bin/bash
export LUCKY_ENV=pro
nohup ./lucky &
